. ./score_ctc_con.sh
. ./score_ctc_lstm.sh
. ./score_ctc_trans.sh
. ./score_ctc_con_lm.sh
. ./score_ctc_lstm_lm.sh