. ./score_mtl_con_lm.sh
. ./score_mtl_lstm_lm.sh
. ./score_mtl_trans_lm.sh