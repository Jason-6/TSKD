. ./score_las_con.sh
. ./score_las_lstm.sh
. ./score_las_trans.sh