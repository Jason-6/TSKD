. ./score_ctc_con_lm_no_pretrain.sh
. ./score_ctc_lstm_lm_no_pretrain.sh
. ./score_ctc_trans_lm_no_pretrain.sh