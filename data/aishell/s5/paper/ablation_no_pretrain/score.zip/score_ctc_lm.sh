. ./score_ctc_con_lm.sh
. ./score_ctc_lstm_lm.sh
. ./score_ctc_trans_lm.sh