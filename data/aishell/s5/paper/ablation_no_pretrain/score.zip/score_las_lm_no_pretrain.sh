. ./score_las_con_lm_no_pretrain.sh
. ./score_las_lstm_lm_no_pretrain.sh
. ./score_las_trans_lm_no_pretrain.sh