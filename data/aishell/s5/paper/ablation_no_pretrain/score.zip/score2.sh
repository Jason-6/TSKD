. ./score_ctc_trans_lm.sh
. ./score_las_con.sh
. ./score_las_lstm.sh
. ./score_las_trans.sh
. ./score_las_con_lm.sh