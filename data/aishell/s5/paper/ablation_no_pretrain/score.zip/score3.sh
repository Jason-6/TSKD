. ./score_las_lstm_lm.sh
. ./score_las_trans_lm.sh
. ./score_mtl_con.sh
. ./score_mtl_lstm.sh
. ./score_mtl_trans.sh