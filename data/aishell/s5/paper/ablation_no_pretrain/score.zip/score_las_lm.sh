. ./score_las_con_lm.sh
. ./score_las_lstm_lm.sh
. ./score_las_trans_lm.sh