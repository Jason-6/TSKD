. ./score_ctc_con.sh
. ./score_ctc_lstm.sh
. ./score_ctc_trans.sh